<template>
	<view class="container">
		<view class="scan" @click="scan">
			<image src="/static/icon_qr.png" mode="aspectFit"></image>
		</view>
		<view class="header">
			<text class="title">智能小车控制</text>
			<text class="subtitle">点击方向按钮控制小车移动,点二维码扫码换车</text>
		</view>

		<view class="control-panel">
			<view class="control-wrapper">
				<view class="control-grid">
					<!-- 前进按钮 -->
					<button class="control-btn btn-up" :disabled="!connected" @touchstart="onUpStart" @touchend="onEnd">
						<image class="btn-img" src="/static/icon_up.png" mode="aspectFit"></image>
					</button>

					<!-- 左转按钮 -->
					<button class="control-btn btn-left" :disabled="!connected" @touchstart="onLeftStart" @touchend="onEnd">
						<image class="btn-img" src="/static/icon_left.png" mode="aspectFit"></image>
					</button>

					<!-- 中心状态指示器 -->
					<view class="status-container">
						<view class="status-indicator" :class="connected ? 'status-online' : 'status-offline'">
							<image class="btn-img" :src="connected ? '/static/online.png' : '/static/offline.png'"
								mode="aspectFit"></image>
						</view>
					</view>

					<!-- 右转按钮 -->
					<button class="control-btn btn-right" :disabled="!connected" @touchstart="onRightStart" @touchend="onEnd">
						<image class="btn-img" src="/static/icon_right.png" mode="aspectFit"></image>
					</button>

					<!-- 后退按钮 -->
					<button class="control-btn btn-down" :disabled="!connected" @touchstart="onDownStart"
						@touchend="onEnd">
						<image class="btn-img" src="/static/icon_down.png" mode="aspectFit"></image>
					</button>
				</view>
			</view>

			<view class="status-alert" :class="connected ? 'status-online' : 'status-offline'">
				<text v-if="connected">小车</text>
				<text v-if="connected" style="color: #666;margin: 0 5px;">[{{formatMacAddress()}}]</text>
				<text v-if="connected">在线</text>

				<text v-if="!connected">小车离线</text>
			</view>
		</view>

		<!-- 语音控制区域 -->
		<view class="voice-wrapper" v-if="connected">
			<button class="voice-btn" :class="{ 'voice-btn-recording': isRecording }" :disabled="!connected"
				@touchstart="onVoiceStart" @touchend="onVoiceEnd" @touchcancel="onVoiceEnd">
				<image class="voice-icon" :src="isRecording ? '/static/mic_active.png' : '/static/mic_normal.png'"
					mode="aspectFit"></image>
				<text>{{ voiceBtnText }}</text>
			</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				writeCharacteristicUUID: '00008001-0000-0010-8000-57616c6b697a',
				notifyCharacteristicUUID: '00008002-0000-0010-8000-57616c6b697a',
				serviceId: '00008000-0000-0010-8000-57616c6b697a',
				deviceId: '',
				device: null,
				isIOS: false,
				isAndroid: true,
				connected: false,
				//语音相关状态
				isRecording: false, // 是否正在录音
				voiceBtnText: '按住说话', // 按钮文字
				recorderManager: null, // 录音管理器
				voiceChunks: [], // 语音数据块
				voiceStartTime: 0, // 录音开始时间（用于时长限制）
				voiceTimer: null // 录音超时定时器
			};
		},
		onLoad() {
			const systemInfo = uni.getSystemInfoSync();
			const platform = systemInfo.platform;

			this.isIOS = platform === 'ios';
			this.isAndroid = platform === 'android';

			this.deviceId = uni.getStorageSync('deviceId') || '';
			if (this.deviceId) {
				this.initBluetooth();
			}

			//预初始化录音管理器（但不启动）
			// #ifdef APP-PLUS || H5 || MP-WEIXIN
			this.initRecorder();
			// #endif
		},
		onUnload() {
			// 页面卸载时关闭蓝牙连接
			if (this.connected) {
				this.disconnect();
			}

			uni.offBLEConnectionStateChange();

			// 关闭蓝牙适配器
			uni.closeBluetoothAdapter();

			// 新增：停止录音并释放资源
			if (this.recorderManager && this.isRecording) {
				this.recorderManager.stop();
			}

			// 清理定时器
			if (this.voiceTimer) {
				clearTimeout(this.voiceTimer);
				this.voiceTimer = null;
			}

			// 清理录音监听器（部分平台需要）
			// #ifdef MP-WEIXIN
			if (this.recorderManager) {
				this.recorderManager.offStart && this.recorderManager.offStart();
				this.recorderManager.offStop && this.recorderManager.offStop();
				this.recorderManager.offFrameRecorded && this.recorderManager.offFrameRecorded();
				this.recorderManager.offError && this.recorderManager.offError();
			}
			// #endif
		},
		methods: {
			// 初始化录音管理器
			initRecorder() {
				// #ifdef APP-PLUS || H5 || MP-WEIXIN
				this.recorderManager = uni.getRecorderManager();

				// 监听录音开始
				this.recorderManager.onStart(() => {
					console.log('录音开始');
					this.isRecording = true;
					this.voiceBtnText = '松开发送';
					this.voiceChunks = []; // 清空上次数据

					// 最长录音10秒，防止无限录
					this.voiceTimer = setTimeout(() => {
						if (this.isRecording) {
							this.onVoiceEnd();
							uni.showToast({
								title: '录音超时',
								icon: 'none'
							});
						}
					}, 10000);
				});

				// 监听录音停止（自然结束或被手动停止）
				this.recorderManager.onStop(async (res) => {
					console.log('录音结束，文件路径:', res.tempFilePath);
					this.isRecording = false;
					this.voiceBtnText = '按住说话';

					if (this.voiceTimer) {
						clearTimeout(this.voiceTimer);
						this.voiceTimer = null;
					}

					// 检查录音时长
					const duration = Date.now() - this.voiceStartTime;
					if (duration < 200) {
						uni.showToast({
							title: '录音时间太短',
							icon: 'none'
						});
						return;
					}

					this.uploadAudioFile(res.tempFilePath);
				});

				// 监听录音错误
				this.recorderManager.onError((err) => {
					console.error('录音失败:', err);
					this.isRecording = false;
					this.voiceBtnText = '按住说话';
					uni.showToast({
						title: '录音失败',
						icon: 'none'
					});
				});
				// #endif
			},
			// 微信小程序 / UniApp 上传录音文件
			uploadAudioFile(filePath) {
				uni.uploadFile({
					url: 'https://211.149.244.78:5267/vosk',
					filePath: filePath,
					name: 'file',
					success: (res) => {
						const data = JSON.parse(res.data);
						console.log('识别结果:', data.data);

						if (data.data.includes('前')) {
							this.onUpStart();
						} else if (data.data.includes('后')) {
							this.onDownStart();
						} else if (data.data.includes('左')) {
							this.onLeftStart();
						} else if (data.data.includes('右')) {
							this.onRightStart();
						} else if (data.data.includes('停')) {
							this.onEnd();
						}
					}
				});
			},
			// 按住开始录音
			onVoiceStart() {
				if (this.isRecording) {
					console.log('isRecording:', isRecording)
					return;
				}

				if (!this.connected) {
					uni.showToast({
						title: '小车未连接',
						icon: 'none'
					});
					return;
				}

				// 配置录音参数
				const recorderOptions = {
					duration: 10000, // 最长10秒
					sampleRate: 8000, // 8kHz采样率（蓝牙传输推荐）
					numberOfChannels: 1, // 单声道
					encodeBitRate: 16000, // 16kbps
					format: 'pcm', // pcm裸数据，便于蓝牙发送
					frameSize: 50 // 每帧50ms
				};

				// 检查权限并初始化
				// #ifdef APP-PLUS || H5
				if (!this.recorderManager) {
					this.initRecorder();
				}

				try {
					this.recorderManager.stop();
				} catch (e) {
					console.log(`recorderManager.stop：${e.message}`);
				}

				this.recorderManager.start(recorderOptions);
				// #endif

				// #ifdef MP-WEIXIN
				if (!this.recorderManager) {
					this.initRecorder();
				}

				try {
					this.recorderManager.stop();
				} catch (e) {
					console.log(`recorderManager.stop：${e.message}`);
				}

				// 微信小程序特殊处理：需要先获取录音权限
				uni.authorize({
					scope: 'scope.record',
					success: () => {
						this.recorderManager.start(recorderOptions);
					},
					fail: () => {
						uni.showToast({
							title: '需要录音权限',
							icon: 'none'
						});
					}
				});
				// #endif
			},

			// 松开结束录音并发送
			onVoiceEnd() {
				if (this.isRecording && this.recorderManager) {
					console.log('recorderManager.stop()');
					this.recorderManager.stop();
				}
			},
			// 初始化蓝牙模块
			initBluetooth() {
				uni.openBluetoothAdapter({
					success: (res) => {
						this.onBLEConnectionStateChange();

						// #ifdef MP-WEIXIN
						this.startSearch();
						// #endif
						
						// #ifdef APP-PLUS

						let formatted = this.deviceId.replace(/:/g, '').match(/.{1,2}/g).join(':');

						this.device = {deviceId: formatted};
						this.connectDevice();
						// #endif
					},
					fail: (err) => {
						console.error('蓝牙适配器打开失败:', err)
						uni.showToast({
							title: '请检查蓝牙是否开启',
							icon: 'none'
						})
					}
				})
			},
			// 开始搜索设备
			startSearch() {
				uni.startBluetoothDevicesDiscovery({
					services: [],
					success: (res) => {
						console.log('开始搜索设备');
						this.listenDevicesFound()
					},
					fail: (err) => {
						console.error('搜索设备失败:', err)
					}
				})
			},
			// 监听发现设备事件
			listenDevicesFound() {
				let devId = this.deviceId.replace(/:/g, '').toLowerCase();

				uni.onBluetoothDeviceFound((devices) => {
					devices.devices.forEach(device => {
						//console.log('设备名称:', device.name);
						//console.log('设备ID:', device.deviceId);

						if (device.advertisData) {
							const data = new Uint8Array(device.advertisData);

							// 或者转换为十六进制字符串
							const hexString = this.byteArrayToHexString(data, 0, data.length)
								.toLowerCase();

							console.log('hexString:', hexString);

							if (hexString.replace(/\s/g, '').indexOf(devId) != -1) {
								console.log('找到设备:', device.deviceId);

								this.device = device;

								this.stopSearch();
								this.connectDevice();
							}
						}
					})
				})
			},
			// 停止搜索
			stopSearch() {
				uni.stopBluetoothDevicesDiscovery({
					success: () => {
						console.log('停止搜索设备')
					}
				})
			},
			// 注册连接状态监听
			onBLEConnectionStateChange() {
				uni.onBLEConnectionStateChange((res) => {
					console.log('蓝牙连接状态变化:', res);

					if (!res.connected) {
						// 设备断开连接
						this.connected = false;
					}
				});
			},
			// 连接设备
			connectDevice() {
				console.log('正在连接设备...', this.device.deviceId)

				uni.createBLEConnection({
					deviceId: this.device.deviceId,
					success: (res) => {
						console.log('设备连接成功');

						this.connected = true;

						if (this.isAndroid) {
							uni.setBLEMTU({
								deviceId: this.device.deviceId,
								mtu: 512,
								success() {
									console.log('MTU设置成功');
								},
								fail() {
									console.log('MTU设置失败');
								}
							})
						}

						this.getServices()
					},
					fail: (err) => {
						console.error('设备连接失败:', err)
						uni.showToast({
							title: '连接失败',
							icon: 'none'
						})
					}
				})
			},
			// 获取设备服务
			getServices() {
				uni.getBLEDeviceServices({
					deviceId: this.device.deviceId,
					success: (res) => {
						console.log('获取服务成功:', res.services)
						this.getCharacteristics()
					},
					fail: (err) => {
						console.error('获取服务失败:', err)
					}
				})
			},
			// 获取特征值
			getCharacteristics() {
				uni.getBLEDeviceCharacteristics({
					deviceId: this.device.deviceId,
					serviceId: this.serviceId,
					success: (res) => {
						console.log('获取特征值成功:', res.characteristics)
						this.enableNotification()
					},
					fail: (err) => {
						console.error('获取特征值失败:', err)
					}
				})
			},
			// 启用通知
			enableNotification() {
				uni.notifyBLECharacteristicValueChange({
					deviceId: this.device.deviceId,
					serviceId: this.serviceId,
					characteristicId: this.notifyCharacteristicUUID,
					state: true,
					success: () => {
						console.log('启用通知成功');

						this.listenCharacteristicValueChange();
					},
					fail: (err) => {
						console.error('启用通知失败:', err)
					}
				})
			},
			// 监听特征值变化
			listenCharacteristicValueChange() {
				uni.onBLECharacteristicValueChange((res) => {
					const data = new Uint8Array(res.value);

					if (data.length > 0) {
						const hexString = this.byteArrayToHexString(data, 0, data.length);
						console.log('接收到数据: ', hexString);
					}
				})
			},
			// 断开连接
			disconnect() {
				uni.closeBLEConnection({
					deviceId: this.device.deviceId,
					success: () => {
						console.log('设备断开连接')
						this.connected = false
					}
				})
			},
			// 发送数据到设备
			send(data) {
				const buffer = new ArrayBuffer(data.length);

				const dataView = new DataView(buffer)
				for (let i = 0; i < data.length; i++) {
					dataView.setUint8(i, data[i]);
				}

				uni.writeBLECharacteristicValue({
					deviceId: this.device.deviceId,
					serviceId: this.serviceId,
					characteristicId: this.writeCharacteristicUUID,
					value: buffer,
					success: () => {
						const hexString = this.byteArrayToHexString(buffer, 0, buffer.byteLength);
						console.log('数据发送成功[' + buffer.byteLength + ']: ', hexString);
					},
					fail: (err) => {
						console.error('数据发送失败:', err)

						uni.showToast({
							title: '数据发送失败',
							icon: 'none'
						});
					}
				})
			},
			byteArrayToHexString(bytes, offset, length) {
				if (bytes instanceof ArrayBuffer) {
					bytes = Array.from(new Uint8Array(bytes));
				}

				if (bytes instanceof Uint8Array) {
					bytes = Array.from(bytes);
				}

				if (!bytes || !Array.isArray(bytes)) {
					return '';
				}

				// 参数边界检查
				if (offset < 0 || offset >= bytes.length) {
					console.warn('Offset out of range, using default offset 0');
					offset = 0;
				}

				if (length <= 0 || offset + length > bytes.length) {
					console.warn('Length out of range, using available length');
					length = bytes.length - offset;
				}

				let hexString = '';
				for (let i = offset; i < offset + length; i++) {
					// 确保字节值在0-255范围内，并格式化为2位十六进制
					const byteValue = bytes[i] & 0xFF;

					if (hexString) {
						hexString += ' ' + byteValue.toString(16).padStart(2, '0');
					} else {
						hexString = byteValue.toString(16).padStart(2, '0');
					}
				}

				return hexString;
			},
			scan() {
				uni.scanCode({
					onlyFromCamera: true,
					scanType: ["qrCode"],
					success: res => {
						console.log('扫码结果', res.result);
						if (res.result) {
							this.deviceId = res.result.replace(/:/g, '');
							uni.setStorageSync('deviceId', this.deviceId);

							// 页面卸载时关闭蓝牙连接
							if (this.connected) {
								this.disconnect();
								uni.offBLEConnectionStateChange();
							}

							// 关闭蓝牙适配器
							uni.closeBluetoothAdapter();

							this.initBluetooth();
						}
					},
					fail: err => {
						console.log('扫码失败', err);
					}
				});
			},
			onUpStart() {
				if (this.connected) {
					console.log('前进开始');
					this.send([0xbf, 0x01, 0xef]);
				}
			},
			onDownStart() {
				if (this.connected) {
					console.log('后退开始');
					this.send([0xbf, 0x02, 0xef]);
				}
			},
			onLeftStart() {
				if (this.connected) {
					console.log('左转开始')
					this.send([0xbf, 0x03, 0xef]);
				}
			},
			onRightStart() {
				if (this.connected) {
					console.log('右转开始');
					this.send([0xbf, 0x04, 0xef]);
				}
			},
			onEnd() {
				if (this.connected) {
					console.log('停止');
					this.send([0xbf, 0x00, 0xef]);
				}
			},
			formatMacAddress() {
				let cleanMac = this.deviceId.replace(/:/g, '');
				let formatted = cleanMac.match(/.{1,2}/g).join(':').toUpperCase();
				return formatted;
			}
		}
	};
</script>

<style lang="scss">
	page {
		background: linear-gradient(145deg, #d8c1ff 0%, #ffffff 100%);
		height: 100vh;
		width: 100%;
	}

	/* 基础样式 */
	.container {
		position: relative;
		padding: 20px;
		padding-top: 66px;
	}

	.scan {
		position: absolute;
		right: 10px;
		top: 50px;
		z-index: 9;
		width: 30px;
		height: 30px;
		padding: 2px;
		background-color: #fff;
		border-radius: 50%;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.scan image {
		width: 60%;
		height: 60%;
	}

	.header {
		text-align: center;
		margin-bottom: 50px;
	}

	.title {
		font-size: 2rem;
		color: #9b6aff;
		font-weight: 600;
		margin-bottom: 10px;
		letter-spacing: 1px;
		display: block;
	}

	.subtitle {
		color: #666;
		font-size: .8rem;
		display: block;
	}

	.control-panel {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 40px;
	}

	.control-wrapper {
		position: relative;
	}

	/* 控制方向键的网格布局 */
	.control-grid {
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		grid-template-rows: repeat(3, 1fr);
		gap: 15px;
		width: 100%;
		height: 100%;
		place-items: center;
	}

	/* 中心状态指示器 */
	.status-container {
		grid-column: 2;
		grid-row: 2;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		z-index: 10;
	}

	.status-indicator {
		width: 80px;
		height: 80px;
		display: flex;
		justify-content: center;
		align-items: center;
		transition: all 0.3s ease;
		position: relative;
	}

	.status-indicator image {
		width: 50%;
		height: 50%;
		border-radius: 50%;
		object-fit: contain;
		padding: 10px;
		background-color: rgba(255, 255, 255, .5);
	}

	/* 方向控制按钮 */
	.control-btn {
		width: 70px;
		height: 70px;
		border-radius: 35px;
		background: linear-gradient(145deg, #d383ff 0%, #2899f7);
		border: none;
		display: flex;
		justify-content: center;
		align-items: center;
		cursor: pointer;
		transition: all 0.15s ease;
		padding: 0;
		margin: 0;
	}

	.control-btn:active {
		transform: translateY(5px);
	}

	.control-btn image {
		width: 80%;
		height: 80%;
		filter: brightness(0.95);
	}

	/* 按钮位置定位 */
	.btn-up {
		grid-column: 2;
		grid-row: 1;
	}

	.btn-left {
		grid-column: 1;
		grid-row: 2;
	}

	.btn-right {
		grid-column: 3;
		grid-row: 2;
	}

	.btn-down {
		grid-column: 2;
		grid-row: 3;
	}

	/* 禁用状态 */
	.control-btn[disabled] {
		cursor: not-allowed;
		opacity: 0.5;
		transform: none;
		box-shadow: none;
	}

	.control-btn[disabled]:active {
		transform: none;
	}

	.control-btn[disabled]:hover {
		background: linear-gradient(145deg, #ba5fff, #3076f5);
	}

	.status-control {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 15px;
		margin-top: 20px;
	}

	.btn-online {
		cursor: not-allowed;
		opacity: 0.5;
		transform: none;
		box-shadow: none;
		background: linear-gradient(145deg, #ba5fff, #3076f5);
	}

	.btn-offline {
		background: linear-gradient(90deg, #6c757d, #495057);
		color: white;
		box-shadow: 0 5px 15px rgba(108, 117, 125, 0.4);
	}

	.status-alert {
		padding: 16px;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.status-alert.status-online {
		color: #07c160;
	}

	.status-alert.status-offline {
		color: #999;
	}

	.btn-img {
		pointer-events: none;
		-webkit-touch-callout: none;
		-webkit-user-drag: none;
		-khtml-user-drag: none;
		-moz-user-drag: none;
		-o-user-drag: none;
		user-drag: none;
		-webkit-user-select: none;
		-moz-user-select: none;
		-ms-user-select: none;
		user-select: none;
	}

	/* 语音控制区域 */
	.voice-wrapper {
		position: fixed;
		bottom: 0;
		z-index: 9;
		left: 20px;
		right: 20px;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		padding: 20px 0;
	}

	.voice-btn {
		width: 200px;
		height: 50px;
		border-radius: 25px;
		background: linear-gradient(145deg, #52c41a, #389e0d);
		/* 绿色渐变 */
		border: none;
		display: flex;
		flex-direction: row;
		align-items: center;
		justify-content: center;
		gap: 8px;
		padding: 0 20px;
		box-shadow: 0 8px 16px rgba(82, 196, 26, 0.3);
		transition: all 0.2s ease;
	}

	.voice-btn-recording {
		background: linear-gradient(145deg, #ff4d4f, #cf1322) !important;
		/* 录音时变红 */
		box-shadow: 0 0 20px rgba(255, 77, 79, 0.6);
		transform: scale(1.05);
	}

	.voice-btn[disabled] {
		opacity: 0.5;
		background: #bfbfbf;
		box-shadow: none;
		transform: none;
	}

	.voice-icon {
		width: 24px;
		height: 24px;
	}

	.voice-btn text {
		color: white;
		font-size: 16px;
		font-weight: 500;
	}

	.voice-hint {
		margin-top: 12px;
		color: #666;
		font-size: 14px;
	}
</style>